import React from 'react'
import { useDispatch } from 'react-redux';
import './Wrapper.scss'

export default function Card({item,}) {
  const dispath = useDispatch()

  const fetchCard = async (id) => {
    const res = await fetch(
      `https://gateway.marvel.com:443/v1/public/characters/${id}?apikey=7be0ab3e80a65349aa66b049c36cc869`
    );
    const resJS = await res.json();
      dispath({
        type: 'CARD_INFO',
        payload:{
          person: resJS.data.results[0]
        }
      })
  };
 
  return (
      <div className='card' onClick={()=>{fetchCard(item.id)}} key={item.id}>
        <img  className='image' src={`${item.thumbnail?.path}.${item.thumbnail?.extension}`} alt='img'/>
        <div className='charaster__name'>
          <h1>{item.name}</h1>
        </div>
      </div>
  )
}

// src={`${item.thumbnail.path}.${item.thumbnail.extension}`}
