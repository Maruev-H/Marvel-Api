import React from "react";
import "./Wrapper.scss";
import Card from "./Card";
import { Button } from "../Button/Button";
import { useSelector } from "react-redux";

export default function Wrapper({ moreCards }) {
  const characters = useSelector((state) => state.characters);
  const person = useSelector((state) => state.person);

  return (
    <>
      <div className="Tooler">
        <div className="Wrapper">
          <div className="Wrapper__content">
            {characters.map((item) => (
              <Card item={item}/>
            ))} 
          </div>
          <Button text="LOAD MORE" className="button red" onClick={moreCards} />
        </div>
          {Object.keys(person).length > 0 ? (
          <div key={person.id}>
            <div className="Tooler__pers" >
              <div>
                <img
                  className="Tooler__img"
                  src={`${person.thumbnail?.path}.${person.thumbnail?.extension}`}
                  alt="png"
                />
              </div>
              <div>
                <h1>{person.name}</h1>
                <div>
                  <Button text="home page" className="button red" />
                </div>
                <Button text="wiki" className="button gray" />
              </div>
            </div>
            <p>{person.description}</p>
          </div>): null}
      </div>
    </>
  );
}
// {person.name}
//         {person.description}
