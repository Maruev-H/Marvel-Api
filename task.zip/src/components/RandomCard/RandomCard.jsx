import React from "react";
import { useSelector } from "react-redux";
import { useState } from "react";
import { useEffect } from "react";
import { Button } from "../Button/Button";
import "./RandomCard.scss";
import { Link } from "react-router-dom";

export default function RandomCard() {
  const charactersID = useSelector((state) => state.charactersID);

  const [randomCard, setRandomCard] = useState([]);

  const fetchRandomCard = async () => {
    let id = charactersID[Math.floor(Math.random() * 18)];

    const res = await fetch(
      `https://gateway.marvel.com:443/v1/public/characters/${id}?apikey=7be0ab3e80a65349aa66b049c36cc869`
    );
    const resJS = await res.json();
    setRandomCard(resJS.data.results[0]);
  };
  useEffect(() => {
    fetchRandomCard();
  }, []);
  console.log(randomCard)

  return (
    <div className="Random">
      <div className="Random__right">
        <div className="Random__img">
          <img
            className="Random__img"
            src={`${randomCard.thumbnail?.path}.${randomCard.thumbnail?.extension}`}
            alt="png"
          />
        </div>
        <div className="Random__text">
          {randomCard.name !== undefined &&
            (randomCard.name.length > 10 ? (
              <h1>{`${randomCard.name.substring(0, 10)}...`}</h1>
            ) : (
              <h1>{randomCard.name}</h1>
            ))}
          <p>{randomCard.description}</p>
          <Link to='/comics'><Button text="home page" className="button red" /></Link>
          <Button text="wiki" className="button gray" />
        </div>
      </div>
      <div className="Random__left">
        <h1>
          Random character for today!<br></br> Do you want to get to know him
          better?
          <br></br>
          <br></br>
          Or choose another one
        </h1>
        <Button
          text="try it"
          className="button red"
          onClick={fetchRandomCard}
        />
      </div>
    </div>
  );
}
