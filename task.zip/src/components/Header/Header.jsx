import React from "react";
import "./Heder.scss";
import { Link } from "react-router-dom";
export default function Header() {
  return (
    <div>
      <nav>
        <button>
          <span>Marvel </span>information portal
        </button>
        <div>
         <Link to='/'><button>Characters</button></Link> / <Link to='/comics'><button>Comics</button></Link>
        </div>
      </nav>
    </div>
  );
}
