import React from "react";
import "./Comisc.scss";
import Avengers from "../pictures/Avengers.png";
import Avengers_logo from "../pictures/Avengers-logo.png";
import { Route, Routes } from "react-router-dom";
import Content from "./Content";

export default function Comisc() {
  return (
    <div className="Comicses">
      <div className="Information">
        <div className="Avengers">
          <img src={Avengers} alt="avengers" />
        </div>
        <h1>
          New comics every week! <br></br>Stay tuned!
        </h1>
        <div className="Avengers-logo">
          <img src={Avengers_logo} alt="avengers-logo" />
        </div>
      </div>
      <Content />
    </div>
  );
}
