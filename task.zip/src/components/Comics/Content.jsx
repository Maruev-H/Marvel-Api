import React from "react";
import "./Comisc.scss";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import ComicsCard from "./ComicsCard";
import {Button} from '../Button/Button'
export default function Content() {
  const dispatch = useDispatch();

  const comics = useSelector((state)=> state.comics);

  const [morecomics, setMoreComics] = useState(8);

  function more (){
    setMoreComics(morecomics + 4)
    fetchComics()
  }

  const fetchComics = async () => {
    const res = await fetch(
      `https://gateway.marvel.com:443/v1/public/comics?limit=${morecomics}&apikey=7be0ab3e80a65349aa66b049c36cc869`
    );

    const resJS = await res.json();

    dispatch({
      type: "GET_COMICS",
      payload: {
        comics: resJS.data.results,
      },
    });
  };
  useEffect(() => {
    fetchComics();
    more();
  }, []);
  return (
    <div>
      <div className="Comics__container">
      {comics.map((item) => 
        <ComicsCard item={item}/>
      )}
      </div>
      <Button text="LOAD MORE" className="button red" onClick={more}/>
    </div>
  )
}
