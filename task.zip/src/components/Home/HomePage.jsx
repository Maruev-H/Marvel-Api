import React from 'react'
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import RandomCard from '../RandomCard/RandomCard'
import Wrapper from '../Wrapper/Wrapper'

export default function HomePage() {
    const dispatch = useDispatch()

  const [cards, setCards] = useState(9)

  function moreCards (){
    setCards(cards + 3)
    fetchAPI()
  }

  const fetchAPI = async () => {
    const res = await fetch(
      `https://gateway.marvel.com/v1/public/characters?limit=${cards}&apikey=7be0ab3e80a65349aa66b049c36cc869`
    );

    const resJS = await res.json()

    dispatch({
      type: "GET_CARDS",
      payload: {
        characters:  resJS.data.results
      }
    })

  };
  useEffect(()=>{
    fetchAPI()
    moreCards()
  }, [])
  return (
    <div>
    <RandomCard />
    <Wrapper moreCards={moreCards} />
    </div>
  )
}
