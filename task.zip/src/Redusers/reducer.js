const initialState = {
  characters: [],
  person: [],
  comics: [],
  charactersID: [
    1011334, 1009150, 1011175, 1011198, 1010846, 1011031, 1011297, 1012717,
    1017851, 1010354, 1017100, 1009144, 1010699, 1009146, 1016823, 1009148,
    1009149, 1010903, 1011266,
  ],
};
const reducer = (state = initialState, action) => {
  switch (action.type) {

    case "GET_CARDS":

      return {
        ...state,
        characters: action.payload.characters,
      };

    case "GET_COMICS":

      return {
        ...state,
        comics: action.payload.comics,
      };

    case "CARD_INFO":

      return {
        ...state,
        person: action.payload.person,
      };

    default:

      return state;
  }
};
export default reducer;
